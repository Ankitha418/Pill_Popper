package com.Pill.Popper.dao.entity;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
