package com.Pill.Popper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class PopperApplication {

	public static void main(String[] args) {
		SpringApplication.run(PopperApplication.class, args);
	}

}
