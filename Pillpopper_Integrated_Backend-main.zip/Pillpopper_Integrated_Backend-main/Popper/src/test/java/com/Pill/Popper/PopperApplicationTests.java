package com.Pill.Popper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PopperApplicationTests {

	@Test
	void contextLoads() {
	}

}
